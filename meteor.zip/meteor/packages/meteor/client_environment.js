Meteor = {
  isClient: true,
  isServer: false
};
