Circles = new Meteor.Collection("circles");
