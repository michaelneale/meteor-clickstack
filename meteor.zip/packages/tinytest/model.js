Meteor._ServerTestResults = new Meteor.Collection('tinytest_results');
